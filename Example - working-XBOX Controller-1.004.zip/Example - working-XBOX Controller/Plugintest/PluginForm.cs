﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using FormSerialisation;
using Xbox360Controller;

namespace Plugins
{
    public partial class PluginForm : Form
    {
        private Plugininterface.Entry UC;
        UCCNCplugin Pluginmain;
        bool mustclose = false;
        
        private GamepadState controls;



        public PluginForm(UCCNCplugin Pluginmain)
        {
            this.UC = Pluginmain.UC;
            this.Pluginmain = Pluginmain;
            InitializeComponent();
        }

        private void PluginForm_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;

            FormSerialisor.Deserialise(this, Application.StartupPath + @"\plugins\xboxcontroller.xml"); // get settings
            controls = new GamepadState(0);
        }

  

        private void PluginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Do not close the form when the red X button is pressed
            //But start a Thread which will stop the Loop call from the UCCNC
            //to prevent the form closing while there is a GUI update in the Loop event

            if (!mustclose)
            {
                e.Cancel = true;
                Thread closethr = new Thread(new ThreadStart(Closeform));
                closethr.Start();
            }
            else
            {
                //Form is closing here...
            }
        }

        public void Closeform()
        {

            

            //Stop the Loop event to update the GUI

            Pluginmain.loopstop = true;
            //Wait until the loop exited
            while (Pluginmain.loopworking)
            {
                Thread.Sleep(10);
            }
            //Set the mustclose variable to true and call the .Close() function to close the Form
            mustclose = true;
            this.Close();
            
        }







        private void button2_Click(object sender, EventArgs e)
        {
            //FormSerialisor.Deserialise(this, Application.StartupPath + @"\plugins\xboxcontroller.xml"); // get settings
        }



        private void button1_Click(object sender, EventArgs e)
        {
            FormSerialisor.Serialise(this, Application.StartupPath + @"\plugins\xboxcontroller.xml");// save settings
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            controls.Vibrate(5, 0);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            controls.Vibrate(0, 0);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                VisitLink();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }



        private void VisitLink()
        {
            // Change the color of the link text by setting LinkVisited 
            // to true.
            linkLabel1.LinkVisited = true;
            //Call the Process.Start method to open the default browser 
            //with a URL:
            System.Diagnostics.Process.Start("mailto:eabrust@craftycnc.com");
        }



        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Change the color of the link text by setting LinkVisited 
            // to true.
            linkLabel1.LinkVisited = true;
            //Call the Process.Start method to open the default browser 
            //with a URL:
            System.Diagnostics.Process.Start("http:\\www.craftycnc.com");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                VisitLink2();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.");
            }
        }



        private void VisitLink2()
        {
            // Change the color of the link text by setting LinkVisited 
            // to true.
            linkLabel1.LinkVisited = true;
            //Call the Process.Start method to open the default browser 
            //with a URL:
            System.Diagnostics.Process.Start(Application.StartupPath + @"\documentation\Buttons_by_number.htm");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            FormSerialisor.Deserialise(this, Application.StartupPath + @"\plugins\xboxcontroller.xml"); // get settings

        }




 

         

      




     









       

        

    }
}
