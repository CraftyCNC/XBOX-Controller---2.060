﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Timers;
using Xbox360Controller;
using SlimDX;
using SlimDX.XInput;



namespace Plugins
{
    public class UCCNCplugin //Class name must be UCCNCplugin to work! 
    {
        bool firstrun = true;  
        public Plugininterface.Entry UC;
        PluginForm myform;
        public bool loopstop = false;
        public bool loopworking = false;
//
        public bool currentStickState1; // Lx
        public bool previousStickState1; // Lx
        public bool currentStickState2;// Ly
        public bool previousStickState2;// Ly
        public bool currentStickState3;// Rx
        public bool previousStickState3;// Rx
        public bool currentStickState4;// Ry
        public bool previousStickState4;//Ry
        public bool currentStickState5;// Rx2
        public bool previousStickState5;// Rx2



        public bool currentA;
        public bool previousA;
        public bool currentB;
        public bool previousB;
        public bool currentX;
        public bool previousX;
        public bool currentY;
        public bool previousY;
        public bool currentBACK;
        public bool previousBACK;
        public bool currentSTART;
        public bool previousSTART;
        public bool currentLS;
        public bool previousLS;
        public bool currentRS;
        public bool previousRS;
        public bool currentUP;
        public bool previousUP;
        public bool currentDOWN;
        public bool previousDOWN;
        public bool currentLEFT;
        public bool previousLEFT;
        public bool currentRIGHT;
        public bool previousRIGHT;


        
        public bool JogEnable;

        public float lsticky;
        public float lstickx;
        public float rsticky;
        public float rstickx;
        public double jogvelLeft;
        public double jogvelRight;
        public double jogvelSet;
        public int originalVel;


        public int JogPlusGo;
        public int JogMinusGo;
        public int JogPlusStop;
        public int JogMinusStop;

        public int JogSelected;
//

        // initialize controller
        public GamepadState controls;

        //

        public UCCNCplugin()
        {
            
        }

        //Called when the plugin is initialised.
        //The parameter is the Plugin interface object which contains all functions prototypes for calls and callbacks.
        public void Init_event(Plugininterface.Entry UC)
        {
            this.UC = UC;
            myform = new PluginForm(this);
        }

        //Called when the plugin is loaded, the author of the plugin should set the details of the plugin here.
        public Plugininterface.Entry.Pluginproperties Getproperties_event(Plugininterface.Entry.Pluginproperties Properties)
        {
            Properties.author = "CraftyCNC";
            Properties.pluginname = "XBox360 Control"; 
            Properties.pluginversion = "1.0004";
            return Properties;
        }

        //Called from UCCNC when the user presses the Configuration button in the Plugin configuration menu.
        //Typically the plugin configuration window is shown to the user.
        public void Configure_event()
        {
            ConfigForm cform = new ConfigForm();
            cform.ShowDialog(); 
        }

        //Called from UCCNC when the plugin is loaded and started.
        public void Startup_event()
        {
            if (myform.IsDisposed)
            {
                myform = new PluginForm(this);
            }
            myform.Show();
            myform.TopMost = false;  //added to send back

            controls = new GamepadState(0);


        }

        //Called when the Pluginshowup(string Pluginfilename); function is executed in the UCCNC.
        public void Showup_event()
        {
            if (myform.IsDisposed)
            {
                myform = new PluginForm(this);
            }
            myform.Show();
            myform.TopMost = false; // added to send back
            myform.BringToFront();
        }

        //Called when the UCCNC software is closing.
        public void Shutdown_event()
        {
            try
            {
                myform.Close();
            }
            catch (Exception) { }
        }

        //Called in a loop with a 25Hz interval.
        public void Loop_event() 
        {
               
            if (loopstop)
            {
                return;
            }

            loopworking = true;

            if (myform == null || myform.IsDisposed)
                return;

            if (firstrun)
            {
                Thread.Sleep(1000);
                
                firstrun = false;
                //Write code here which has to be run on first cycle only...   
                bool testfeed = int.TryParse(myform.comboBox25.Text, out originalVel);
                
                //MessageBox.Show(testfeed.ToString());
                if ((!testfeed) || (originalVel < 1) || (originalVel > 100))
                {
                    MessageBox.Show(myform, "Please enter a numerical value between 1-100 for default feedrate and save setting", "Default Feedrate Setting Needs Value Entered");
                    
                }
            }

            try
            {

                controls.Update();


                # region    GET BUTTON/STICK DATA
                lsticky = (controls.LeftStick.Position.Y);
                lstickx = (controls.LeftStick.Position.X);
                rsticky = (controls.RightStick.Position.Y);
                rstickx = (controls.RightStick.Position.X);
                float ltrig = (controls.LeftTrigger);
                float rtrig = (controls.RightTrigger); 
               

                bool A = controls.A;
                bool B = controls.B;
                bool X = controls.X;
                bool Y = controls.Y;
                bool LS = controls.LeftShoulder;
                bool RS = controls.RightShoulder;
                bool up = controls.DPad.Up;
                bool down = controls.DPad.Down;
                bool left = controls.DPad.Left;
                bool right = controls.DPad.Right;
                bool back = controls.Back;
                bool start = controls.Start;

                // Used for testing feedback
                string LSX = Convert.ToString(lstickx);
                string LSY = Convert.ToString(lsticky);
                string RSX = Convert.ToString(rstickx);
                string RSY = Convert.ToString(rsticky);
                string LT = Convert.ToString(ltrig);
                string RT = Convert.ToString(rtrig);


                string Abutton = Convert.ToString(A);
                string Bbutton = Convert.ToString(B);
                string Xbutton = Convert.ToString(X);
                string Ybutton = Convert.ToString(Y);
                string LSbutton = Convert.ToString(LS);
                string RSbutton = Convert.ToString(RS);
                
                string Upbutton = Convert.ToString(up);
                string Downbutton = Convert.ToString(down);
                string Leftbutton = Convert.ToString(left);
                string Rightbutton = Convert.ToString(right);
                string Backbutton = Convert.ToString(back);
                string Startbutton = Convert.ToString(start);

                myform.label1.Text = "LeftX: " + String.Format("{0:0.000}",lstickx); // UC.Getfield(true, 226);
                myform.label2.Text = "LeftY: " + String.Format("{0:0.000}",lsticky);  // UC.Getfield(true, 227);
                myform.label3.Text = "RightX: " + String.Format("{0:0.000}",rstickx); // UC.Getfield(true, 226);
                myform.label4.Text = "RightY: " + String.Format("{0:0.000}",rsticky);  // UC.Getfield(true, 227);
                myform.label5.Text = "Ltrigger: " + String.Format("{0:0.000}",ltrig); // UC.Getfield(true, 228);
                myform.label6.Text = "Rtrigger: " + String.Format("{0:0.000}",rtrig); // UC.Getfield(true, 229); 

                myform.label7.Text = "A: " + Abutton; // UC.Getfield(true, 228);
                myform.label8.Text = "B: " + Bbutton; // UC.Getfield(true, 229); 
                myform.label9.Text = "X: " + Xbutton; // UC.Getfield(true, 867);
                myform.label10.Text = "Y: " + Ybutton; // UC.Getfield(true, 868);

                myform.label11.Text = "LS: " + LSbutton; // UC.Getfield(true, 228);
                myform.label12.Text = "RS: " + RSbutton; // UC.Getfield(true, 229); 
                myform.label13.Text = "Back: " + Backbutton; // UC.Getfield(true, 867);
                myform.label14.Text = "Start: " + Startbutton; // UC.Getfield(true, 868);

                myform.label15.Text = "DpadUp: " + Upbutton; // UC.Getfield(true, 228);
                myform.label16.Text = "DpadDown: " + Downbutton; // UC.Getfield(true, 229); 
                myform.label17.Text = "DpadL: " + Leftbutton; // UC.Getfield(true, 867);
                myform.label18.Text = "DpadR: " + Rightbutton; // UC.Getfield(true, 868);
                // End testing feedback

                myform.label19.Text = "feedrate: " + Convert.ToString(0); // UC.Getfield(true, 868);
                myform.label20.Text = "feedrate: " + Convert.ToString(0); // UC.Getfield(true, 868);
                #endregion   
                
                #region SAFETY ENABLE   
                
                if (myform.radioButton7.Checked)
                {
                    if (ltrig > .5 && rtrig > .5 && myform.checkBox1.Checked)
                        JogEnable = true;
                    else
                        JogEnable = false;
                }
                else if (myform.radioButton8.Checked)
                {
                    if ((ltrig>.5 || rtrig>.5) && myform.checkBox1.Checked)
                        JogEnable = true;
                    else
                        JogEnable = false;
                }
                else if (myform.radioButton9.Checked)
                {
                    JogEnable = myform.checkBox1.Checked;
                }



                #endregion 


                #region PerformButtonActions
                
                
                // Start of stick action and sending jog commands to UCCNC


                if (myform.checkBox1.Checked == true)
                //if (JogEnable==true)
                {
                

                CheckStickLX(lstickx);
                CheckStickLY(lsticky);
                CheckStickRX(rstickx);
                CheckStickRY(rsticky);

                CheckA(A);
                CheckB(B);
                CheckX(X);
                CheckY(Y);
                CheckSTART(start);
                CheckBACK(back);
                CheckLS(LS);
                CheckRS(RS);

                CheckUP(up);
                CheckDOWN(down);
                CheckLEFT(left);
                CheckRIGHT(right);
                }
                
                #endregion  


                // Pickup new velocity default value:
                bool testfeed = int.TryParse(myform.comboBox25.Text, out originalVel);


                #region Velocity_calcs
                //Left stick velocity
                if ((Math.Abs(lstickx) >= .01) || (Math.Abs(lsticky) >=.01))  // turn on action for velocity source
                {
                    
                    //double jogvelLeft;
                    jogvelLeft = Math.Sqrt(Math.Abs(lstickx) * Math.Abs(lstickx) + Math.Abs(lsticky) * Math.Abs(lsticky));                   
                    

                    // sensitivity selector  
                    if (myform.radioButton1.Checked) // jogvel
                    {                    
                        jogvelLeft = jogvelLeft * 50;
                    }
                    else if (myform.radioButton2.Checked)
                    {
                        jogvelLeft = jogvelLeft * jogvelLeft * 50;//jogvel^2
                    }
                    else if (myform.radioButton3.Checked)
                    {
                        jogvelLeft = jogvelLeft * jogvelLeft * jogvelLeft* 50;//jogvel^3 best
                    }
                    //else
                    //    MessageBox.Show("error selecting speed");

                    if (myform.radioButton9.Checked) // If the shoulder button is not safety enable, use to modify velocity
                    {
                        double accelLeft;
                        accelLeft = ltrig + 1; // set accel to be between 1-2 with trigger pull

                        jogvelLeft = jogvelLeft * accelLeft;  //velocity is mix of stick and trigger actions
                    }
                    else if (myform.radioButton7.Checked ||myform.radioButton8.Checked)  // If using the shoulder as a safety.... velocity scale to 100
                    {
                        jogvelLeft = jogvelLeft * 2; 
                    }
                    


                    myform.label19.Text = "feedrate: " + String.Format("{0:0.000}",jogvelLeft)+ " %"; // UC.Getfield(true, 868);


                    if (JogEnable == true)
                    {
                        UC.Setfield(false, jogvelLeft, 913);
                        UC.Validatefield(false, 913);
                    }
                }


                //Right stick velocity
                //if ((Math.Abs(rsticky) >= .01))  // turn on action for velocity source - removed x axis from check
                if ((Math.Abs(rstickx) >= .01) || (Math.Abs(rsticky) >= .01))  // turn on action for velocity source
                {

                    //double jogvelRight;
                    //jogvelRight = Math.Abs(rsticky); //removed x axis 
                    jogvelRight = Math.Sqrt(Math.Abs(rstickx) * Math.Abs(rstickx) + Math.Abs(rsticky) * Math.Abs(rsticky));

                    // sensitivity selector
                    if (myform.radioButton4.Checked)
                    {
                        jogvelRight = jogvelRight * 50;
                    }
                    else if (myform.radioButton5.Checked)
                    {
                        jogvelRight = jogvelRight * jogvelRight * 50;//jogvel^2
                    }
                    else if (myform.radioButton6.Checked)
                    {
                        jogvelRight = jogvelRight * jogvelRight * jogvelRight * 50;//jogvel^3 best
                    }
                    //else
                    //    MessageBox.Show("error selecting speed");
                    

                    
                    if (myform.radioButton9.Checked)
                    {
                    double accelRight;                  
                    accelRight = rtrig + 1; // set accel to be between 1-2 with trigger pull
                    
                    jogvelRight = jogvelRight * accelRight;  //velocity is mix of stick and trigger actions
                    }
                    else if (myform.radioButton7.Checked || myform.radioButton8.Checked)  // If using the shoulder as a safety.... velocity scale to 100
                    {
                    jogvelRight = jogvelRight * 2;  
                    }

                    myform.label20.Text = "feedrate: " + String.Format("{0:0.000}", jogvelRight) +" %"; 







                    if (JogEnable == true)
                    {
                        UC.Setfield(false, jogvelRight, 913);
                        UC.Validatefield(false, 913);
                    }
                }

                // pick source:

                //if (jogvelLeft < jogvelRight)
                //{
                //    if (jogvelLeft < 0.01)
                //    {
                //        jogvelSet = jogvelRight;
                //    }
                //    else
                //    {
                //        jogvelSet = jogvelLeft;
                //    }
                //}
                //else
                //{
                //    if (jogvelRight < 0.01)
                //    {
                //        jogvelSet = jogvelLeft;
                //    }
                //    else
                //    {
                //        jogvelSet = jogvelRight;
                //    }
                //}

                
                
                
                //if ((Math.Abs(lstickx) > .01) || (Math.Abs(lsticky) > .01) || (Math.Abs(rsticky) > .01))
                //{
                //    if (JogEnable == true)
                //    {
                //        UC.Setfield(false, jogvelSet, 913);
                //        UC.Validatefield(false, 913);
                //    }

                //}


                #endregion
                //End of Trigger actions




            }
            catch (Exception) { }

            loopworking = false;
            //Console.WriteLine("" + Convert.ToInt32('A'));
        }



        //Called when the user presses a button on the UCCNC GUI or if a Callbutton function is executed.
        //The int buttonnumber parameter is the ID of the caller button.
        // The bool onscreen parameter is true if the button was pressed on the GUI and is false if the Callbutton function was called.
        public void Buttonpress_event(int buttonnumber, bool onscreen)
        {
            if (onscreen)
            {
                if (buttonnumber == 128)
                {
                    
                }
            }
        }

        #region Sticks Actions
    
	

        // Sub to start/stop axis with button presses based on stick positioning

        //  Left Stick =  X Axis
        public void CheckStickLX(double stick)
        {

            
            // Assign axis/buttons from pulldowns
            
            
            
            
            
            string LXAssign = myform.comboBoxLXStick.Text;
             

            switch(LXAssign)
            {
                case "Xaxis":
                    JogPlusGo = 147;
                    JogMinusGo = 148;
                    JogPlusStop = 229;
                    JogMinusStop = 230;
                    break;
                case "Yaxis":
                    JogPlusGo = 149;
                    JogMinusGo = 150;
                    JogPlusStop = 231;
                    JogMinusStop = 232;        
                    break;
                case "Zaxis":
                    JogPlusGo = 151;
                    JogMinusGo = 152;
                    JogPlusStop = 233;
                    JogMinusStop = 234;        
                    break;
                case "Aaxis":
                    JogPlusGo = 153;
                    JogMinusGo = 154;
                    JogPlusStop = 235;
                    JogMinusStop = 236;
                    break;
                case "Baxis":
                    JogPlusGo = 155;
                    JogMinusGo = 156;
                    JogPlusStop = 237;
                    JogMinusStop = 238;
                    break;
                case "Caxis":
                    JogPlusGo = 157;
                    JogMinusGo = 158;
                    JogPlusStop = 239;
                    JogMinusStop = 240;
                    break;
                default:
                    JogPlusGo = 0;
                    JogMinusGo = 0;
                    JogPlusStop = 0;
                    JogMinusStop = 0;
                    break;
            }

            
            
            //if ((Math.Abs(lstickx)==0) && (Math.Abs(lsticky)==0) && (Math.Abs(rsticky)==0))
            //{
            //    originalVel = Convert.ToDouble(UC.Getfield(false, 913));  // get original feedrate
            //}
            
            currentStickState1 = (Math.Abs(stick) > .02);

            
            if(currentStickState1 == true && previousStickState1 == false)
            {
            //button just pressed, call code
                

            if (JogEnable && ((!myform.checkBox2.Checked) || ((myform.checkBox2.Checked) && (Math.Abs(lstickx) > Math.Abs(lsticky)))))
            {
                if (stick > .02)
                {
                    UC.Callbutton(JogPlusGo);   //  Jog+ code
                }
                else
                {
                    UC.Callbutton(JogMinusGo);   // Jog- code
                }
            }
            }

            if((currentStickState1== false && previousStickState1 == true))  //additional functionality if desired
            {
            //button just released, call other code
                    UC.Callbutton(JogPlusStop);  // X Jog stop codes
                    UC.Callbutton(JogMinusStop);
                    UC.Setfield(false, originalVel, 913);
                    UC.Validatefield(false, 913);
            }

            previousStickState1 = currentStickState1;
        }





        //  Left Stick =  Y Axis
        public void CheckStickLY(double stick)
        {

            //if ((Math.Abs(lstickx) == 0) && (Math.Abs(lsticky) == 0) && (Math.Abs(rsticky) == 0))
            //{
            //    originalVel = Convert.ToDouble(UC.Getfield(false, 913));  // get original feedrate;

            //    MessageBox.Show(Convert.ToString(originalVel));
            //}
            
            
            currentStickState2 = (Math.Abs(stick) > .02);


            string LYAssign = myform.comboBoxLYStick.Text;


            switch (LYAssign)
            {
                case "Xaxis":
                    JogPlusGo = 147;
                    JogMinusGo = 148;
                    JogPlusStop = 229;
                    JogMinusStop = 230;
                    break;
                case "Yaxis":
                    JogPlusGo = 149;
                    JogMinusGo = 150;
                    JogPlusStop = 231;
                    JogMinusStop = 232;
                    break;
                case "Zaxis":
                    JogPlusGo = 151;
                    JogMinusGo = 152;
                    JogPlusStop = 233;
                    JogMinusStop = 234;
                    break;
                case "Aaxis":
                    JogPlusGo = 153;
                    JogMinusGo = 154;
                    JogPlusStop = 235;
                    JogMinusStop = 236;
                    break;
                case "Baxis":
                    JogPlusGo = 155;
                    JogMinusGo = 156;
                    JogPlusStop = 237;
                    JogMinusStop = 238;
                    break;
                case "Caxis":
                    JogPlusGo = 157;
                    JogMinusGo = 158;
                    JogPlusStop = 239;
                    JogMinusStop = 240;
                    break;
                default:
                                        JogPlusGo = 0;
                    JogMinusGo = 0;
                    JogPlusStop = 0;
                    JogMinusStop = 0;
                    break;
            }


            if (currentStickState2 == true && previousStickState2 == false)
            {
                //button just pressed, call code

             if (JogEnable && ((!myform.checkBox2.Checked) || ((myform.checkBox2.Checked) && (Math.Abs(lsticky) > Math.Abs(lstickx)))))
            {
                if (stick > .02)
                {
                    UC.Callbutton(JogPlusGo);   //  Jog+ code
                }
                else
                {
                    UC.Callbutton(JogMinusGo);   // Jog- code
                }
            }
            }

            if((currentStickState2== false && previousStickState2 == true))  //additional functionality if desired
            {
            //button just released, call other code
                    UC.Callbutton(JogPlusStop);  // X Jog stop codes
                    UC.Callbutton(JogMinusStop);
                    UC.Setfield(false, originalVel, 913);
                    UC.Validatefield(false, 913);
            }


            previousStickState2 = currentStickState2;
        }




        //  Right Stick =  X Axis
        public void CheckStickRX(double stick)
        {
            currentStickState3 = (Math.Abs(stick) > .02);


            string RXAssign = myform.comboBoxRXStick.Text;
            bool JogStepSelect;

            switch (RXAssign)
            {
                case "Xaxis":
                    JogPlusGo = 147;
                    JogMinusGo = 148;
                    JogPlusStop = 229;
                    JogMinusStop = 230;
                    JogStepSelect = false;
                    break;
                case "Yaxis":
                    JogPlusGo = 149;
                    JogMinusGo = 150;
                    JogPlusStop = 231;
                    JogMinusStop = 232;
                    JogStepSelect = false;
                    break;
                case "Zaxis":
                    JogPlusGo = 151;
                    JogMinusGo = 152;
                    JogPlusStop = 233;
                    JogMinusStop = 234;
                    JogStepSelect = false;
                    break;
                case "Aaxis":
                    JogPlusGo = 153;
                    JogMinusGo = 154;
                    JogPlusStop = 235;
                    JogMinusStop = 236;
                    JogStepSelect = false;
                    break;
                case "Baxis":
                    JogPlusGo = 155;
                    JogMinusGo = 156;
                    JogPlusStop = 237;
                    JogMinusStop = 238;
                    JogStepSelect = false;
                    break;
                case "Caxis":
                    JogPlusGo = 157;
                    JogMinusGo = 158;
                    JogPlusStop = 239;
                    JogMinusStop = 240;
                    JogStepSelect = false;
                    break;
                case "JogStep":
                    JogPlusGo = 0;
                    JogMinusGo = 0;
                    JogPlusStop = 0;
                    JogMinusStop = 0;
                    JogStepSelect = true;
                    break;
                default:
                    JogPlusGo = 0;
                    JogMinusGo = 0;
                    JogPlusStop = 0;
                    JogMinusStop = 0;
                    JogStepSelect = false;
                    break;
            }


            if (JogStepSelect == false)
            {
                if (currentStickState3 == true && previousStickState3 == false)
                {
                    //button just pressed, call code

                    if (JogEnable && ((!myform.checkBox2.Checked) || ((myform.checkBox2.Checked) && (Math.Abs(rstickx) > Math.Abs(rsticky)))))
                    {
                        if (stick > .02)
                        {
                            UC.Callbutton(JogPlusGo);   //  Jog+ code
                        }
                        else
                        {
                            UC.Callbutton(JogMinusGo);   // Jog- code
                        }
                    }
                }


                if ((currentStickState3 == false && previousStickState3 == true))  //additional functionality if desired
                {
                    //button just released, call other code
                    UC.Callbutton(JogPlusStop);  // X Jog stop codes
                    UC.Callbutton(JogMinusStop);
                    UC.Setfield(false, originalVel, 913);
                    UC.Validatefield(false, 913);
                }


                previousStickState3 = currentStickState3;

            }








            if (JogStepSelect == true)
            {


                //int JogSelected = 0;
                    currentStickState5 = (Math.Abs(stick) > .8);
                    currentStickState3 = (Math.Abs(stick) > .2);

                    if (currentStickState5 == true && previousStickState5 == false)
                    {
                        //button just pressed, call code

                        //originalVel = Convert.ToDouble(UC.Getfield(false, 913));  // get original feedrate
                        if ((!myform.checkBox3.Checked) || ((myform.checkBox3.Checked) && (Math.Abs(rstickx) > Math.Abs(rsticky))))
                       
                        {
                            if (stick > 0)
                            {
                                JogSelected = 4;
                                double Jog4;
                                bool test = double.TryParse(myform.jog4.Text, out Jog4);
                                if (test)
                                {
                                    UC.Setfield(false, Jog4, 2027);
                                    UC.Validatefield(false, 2027);
                                }
                                else  // default value
                                {
                                    UC.Callbutton(166);   // Full left code
                                }


                                //if (myform.checkBox4.Checked)
                                //{

                                //        Shake(4, 50);
                                    
                                //}         
                                

                            }
                            else
                            {
                               
                                //full left code  // override value
                                JogSelected = 1;
                                double Jog1;
                                bool test = double.TryParse(myform.jog1.Text, out Jog1);
                                if (test)
                                {
                                    UC.Setfield(false, Jog1, 2027);
                                    UC.Validatefield(false, 2027);
                                }
                                else  // default value
                                {
                                    UC.Callbutton(241);   // Full left code
                                }
                                
                                
                                //if (myform.checkBox4.Checked)
                                //{

                                //        Shake(1, 50);
                                    
                                //}
                                

                            }
                        }
                    }
            
                    


                    if (currentStickState3 == true && previousStickState3 == false)
                    {
                        //button just pressed, call code

                        //originalVel = Convert.ToDouble(UC.Getfield(false, 913));  // get original feedrate
                        if ((!myform.checkBox3.Checked) || ((myform.checkBox3.Checked) && (Math.Abs(rstickx) > Math.Abs(rsticky))))
                        {
                            if (stick >0)
                            {

                            JogSelected = 3;
                            double Jog3;
                            bool test = double.TryParse(myform.jog3.Text, out Jog3);
                            if (test)
                            {
                                UC.Setfield(false, Jog3, 2027);
                                UC.Validatefield(false, 2027);
                            
                            }
                            else  // default value
                            {
                                UC.Callbutton(165);   // Full left code
                            }


                            //if (myform.checkBox4.Checked)
                            //{

                            //        Shake(3, 50);
  
                            //}


                        }
                        else
                        {

                            //full left code  // override value
                            JogSelected = 2;
                            double Jog2;
                            bool test = double.TryParse(myform.jog2.Text, out Jog2);
                            if (test)
                            {
                                UC.Setfield(false, Jog2, 2027);
                                UC.Validatefield(false, 2027);
                            }
                            else  // default value
                            {
                                UC.Callbutton(164);   // Full left code
                            }
                            }
                        }
                    }


                    if (currentStickState3 == false && previousStickState3 == true)
                        //additional functionality if desired-released
                    {

                        if (myform.checkBox4.Checked)
                        {
                            if (JogSelected == 1)
                            {
                                Shake(1, 50);
                                //Console.Beep();
                                //Console.Beep(10, 50);
                                //System.Media.SystemSounds.Beep.Play();
                            }
                            else if (JogSelected == 2)
                            {
                                Shake(2, 50);
                                //System.Media.SystemSounds.Asterisk.Play();
                            }
                            else if (JogSelected == 3)
                            {
                                Shake(3, 50);
                                //System.Media.SystemSounds.Hand.Play();
                            }
                            else if (JogSelected == 4)
                            {
                                Shake(4, 50);
                                //System.Media.SystemSounds.Exclamation.Play();
                            }
                        }

                    }




                    previousStickState3 = currentStickState3;
                    previousStickState5 = currentStickState5;



                   


            }
        }

                        
                    
            



                                     
            

                










        


      


        //  Right Stick =  Y Axis
        public void CheckStickRY(double stick)
        
            {
                currentStickState4 = (Math.Abs(stick) > .02);


                string RYAssign = myform.comboBoxRYStick.Text;


                switch (RYAssign)
                {
                    case "Xaxis":
                        JogPlusGo = 147;
                        JogMinusGo = 148;
                        JogPlusStop = 229;
                        JogMinusStop = 230;
                        break;
                    case "Yaxis":
                        JogPlusGo = 149;
                        JogMinusGo = 150;
                        JogPlusStop = 231;
                        JogMinusStop = 232;
                        break;
                    case "Zaxis":
                        JogPlusGo = 151;
                        JogMinusGo = 152;
                        JogPlusStop = 233;
                        JogMinusStop = 234;
                        break;
                    case "Aaxis":
                        JogPlusGo = 153;
                        JogMinusGo = 154;
                        JogPlusStop = 235;
                        JogMinusStop = 236;
                        break;
                    case "Baxis":
                        JogPlusGo = 155;
                        JogMinusGo = 156;
                        JogPlusStop = 237;
                        JogMinusStop = 238;
                        break;
                    case "Caxis":
                        JogPlusGo = 157;
                        JogMinusGo = 158;
                        JogPlusStop = 239;
                        JogMinusStop = 240;
                        break;
                    default:
                                            JogPlusGo = 0;
                    JogMinusGo = 0;
                    JogPlusStop = 0;
                    JogMinusStop = 0;
                        break;
                }


                if (currentStickState4 == true && previousStickState4 == false)
                {
                    //button just pressed, call code

                    if (JogEnable && ((!myform.checkBox2.Checked) || ((myform.checkBox2.Checked) && (Math.Abs(rsticky) > Math.Abs(rstickx)))))
                    {
                        if (stick > .02)
                        {
                            UC.Callbutton(JogPlusGo);   //  Jog+ code
                        }
                        else
                        {
                            UC.Callbutton(JogMinusGo);   // Jog- code
                        }
                    }
                }

                if ((currentStickState4 == false && previousStickState4 == true))  //additional functionality if desired
                {
                    //button just released, call other code
                    UC.Callbutton(JogPlusStop);  // X Jog stop codes
                    UC.Callbutton(JogMinusStop);
                    UC.Setfield(false, originalVel, 913);
                    UC.Validatefield(false, 913);
                }


                previousStickState4 = currentStickState4;
            }


    
#endregion


        #region Button Actions
        // Button state checks and actions to perform
        //  A Button
        public void CheckA(bool A)
        {
            currentA = A;

            if (currentA == true && previousA == false)
            {
                //button just pressed, call code
                {
                    int OnA;
                    bool test = Int32.TryParse(myform.comboBox2.Text,out OnA);
                    
                    //int OnA = Convert.ToInt32(myform.comboBox2.Text);
                    if (test)
                    {
                        UC.Callbutton(OnA);  // Z+ Jog code
                    }
                }
            }
            if (currentA == false && previousA == true)  //additional functionality if desired
            {
                //button just released, call other code
                int OffA;
                bool test = Int32.TryParse(myform.comboBox1.Text, out OffA);
                
                //int OffA = Convert.ToInt32(myform.comboBox1.Text);
                if (test)
                {
                    UC.Callbutton(OffA);// Z Jog stop codes
                }  

            }

            previousA = currentA;
        }

        //  B Button
        public void CheckB(bool B)
        {
            currentB = B;

            if (currentB == true && previousB == false)
            {
                //button just pressed, call code

                {
                    int OnB;
                    bool test = Int32.TryParse(myform.comboBox4.Text, out OnB);

                    //int OnA = Convert.ToInt32(myform.comboBox2.Text);
                    if (test)
                    {
                        UC.Callbutton(OnB);  // Z+ Jog code
                    }
                }

            }
            if (currentB == false && previousB == true)  //additional functionality if desired
            {
                //button just released, call other code
                int OffB;
                bool test = Int32.TryParse(myform.comboBox3.Text, out OffB);

                //int OffA = Convert.ToInt32(myform.comboBox1.Text);
                if (test)
                {
                    UC.Callbutton(OffB);// Z Jog stop codes
                }
            }


            previousB = currentB;
        }


        //  X Button
        public void CheckX(bool X)
        {
            currentX = X;

            if (currentX == true && previousX == false)
            {
                //button just pressed, call code
                {
                    int OnX;
                    bool test = Int32.TryParse(myform.comboBox6.Text, out OnX);

                    //int OnA = Convert.ToInt32(myform.comboBox2.Text);
                    if (test)
                    {
                        UC.Callbutton(OnX);  // Z+ Jog code
                    }
                }

            }
            if (currentX == false && previousX == true)  //additional functionality if desired
            {
                //button just released, call other code
                int OffX;
                bool test = Int32.TryParse(myform.comboBox5.Text, out OffX);

                //int OffA = Convert.ToInt32(myform.comboBox1.Text);
                if (test)
                {
                    UC.Callbutton(OffX);// Z Jog stop codes
                }
            }


            previousX = currentX;
        }


        //  Y Button
        public void CheckY(bool Y)
        {
            currentY = Y;

            if (currentY == true && previousY == false)
            {
                //button just pressed, call code
                {
                    int OnY;
                    bool test = Int32.TryParse(myform.comboBox8.Text, out OnY);

                    //int OnA = Convert.ToInt32(myform.comboBox2.Text);
                    if (test)
                    {
                        UC.Callbutton(OnY);  // Z+ Jog code
                    }
                }

            }
            if (currentY == false && previousY == true)  //additional functionality if desired
            {
                //button just released, call other code
                int OffY;
                bool test = Int32.TryParse(myform.comboBox7.Text, out OffY);

                //int OffA = Convert.ToInt32(myform.comboBox1.Text);
                if (test)
                {
                    UC.Callbutton(OffY);// Z Jog stop codes
                }
            }


            previousY = currentY;
        }

        //  LS Button
        public void CheckLS(bool LS)
        {
            currentLS = LS;

            if (currentLS == true && previousLS == false)
            {
                //button just pressed, call code

                UC.Callbutton(162); // set mode to step jog

                UC.Callbutton(151); //Jog z+
            }
            if (currentLS == false && previousLS == true)  //additional functionality if desired
            {
                //button just released, call other code
                
                UC.Callbutton(233); // axis stop

                UC.Callbutton(161); // set mode to continuous jog

            }

            previousLS = currentLS;
        }

        //  RS Button
        public void CheckRS(bool RS)
        {
            currentRS = RS;

            if (currentRS == true && previousRS == false)
            {
                //button just pressed, call code
                
                UC.Callbutton(162); // set mode to step jog

                UC.Callbutton(152); //Jog z-
            }
            if (currentRS == false && previousRS == true)  //additional functionality if desired
            {
                //button just released, call other code

                UC.Callbutton(234); // axis stop

                UC.Callbutton(161); // set mode to continuous jog

            }

            previousRS = currentRS;
        }

        //  START Button
        public void CheckSTART(bool START)
        {
            currentSTART = START;

            if (currentSTART == true && previousSTART == false)
            {
                //button just pressed, call code
                {
                    int OnSTART;
                    bool test = Int32.TryParse(myform.comboBox16.Text, out OnSTART);

                    //int OnA = Convert.ToInt32(myform.comboBox2.Text);
                    if (test)
                    {
                        UC.Callbutton(OnSTART);  // Z+ Jog code
                    }
                }

            }
            if (currentSTART == false && previousSTART == true)  //additional functionality if desired
            {
                //button just released, call other code
                int OffSTART;
                bool test = Int32.TryParse(myform.comboBox15.Text, out OffSTART);

                //int OffA = Convert.ToInt32(myform.comboBox1.Text);
                if (test)
                {
                    UC.Callbutton(OffSTART);// Z Jog stop codes
                }
            }


            previousSTART = currentSTART;
        }

        //  BACK Button
        public void CheckBACK(bool BACK)
        {
            currentBACK = BACK;

            if (currentBACK == true && previousBACK == false)
            {
                //button just pressed, call code
                {
                    int OnBACK;
                    bool test = Int32.TryParse(myform.comboBox14.Text, out OnBACK);

                    //int OnA = Convert.ToInt32(myform.comboBox2.Text);
                    if (test)
                    {
                        UC.Callbutton(OnBACK);  // Z+ Jog code
                    }
                }

            }
            if (currentBACK == false && previousBACK == true)  //additional functionality if desired
            {
                //button just released, call other code
                int OffBACK;
                bool test = Int32.TryParse(myform.comboBox13.Text, out OffBACK);

                //int OffA = Convert.ToInt32(myform.comboBox1.Text);
                if (test)
                {
                    UC.Callbutton(OffBACK);// Z Jog stop codes
                }
            }


            previousBACK = currentBACK;
        }


        //  UP Button
        public void CheckUP(bool UP)
        {
            currentUP = UP;

            if (currentUP == true && previousUP == false)
            {
                //button just pressed, call code
               
                 UC.Callbutton(162); // set mode to step jog
                  
                 UC.Callbutton(149); //Jog y+

            }
            if (currentUP == false && previousUP == true)  //additional functionality if desired
            {
                //button just released, call other code

                UC.Callbutton(231); // axis stop

                UC.Callbutton(161); // set mode to continuous jog


                //int OffUP = Convert.ToInt32(myform.numericUpDown2.Value);
                //UC.Callbutton(OffUP);  // Z Jog stop codes
            }

            previousUP = currentUP;
        }


        //  DOWN Button
        public void CheckDOWN(bool DOWN)
        {
            currentDOWN = DOWN;

            if (currentDOWN == true && previousDOWN == false)
            {
                //button just pressed, call code

                UC.Callbutton(162); // set mode to step jog

                UC.Callbutton(150); //Jog y-
            }
            if (currentDOWN == false && previousDOWN == true)  //additional functionality if desired
            {
                //button just released, call other code

                UC.Callbutton(232); // axis stop

                UC.Callbutton(161); // set mode to continuous jog

            }

            previousDOWN = currentDOWN;
        }


        //  LEFT Button
        public void CheckLEFT(bool LEFT)
        {
            currentLEFT = LEFT;

            if (currentLEFT == true && previousLEFT == false)
            {
                //button just pressed, call code

                UC.Callbutton(162); // set mode to step jog

                UC.Callbutton(148); //Jog x-
            }
            if (currentLEFT == false && previousLEFT == true)  //additional functionality if desired
            {
                //button just released, call other code


                UC.Callbutton(230); // axis stop

                UC.Callbutton(161); // set mode to continuous jog

            }

            previousLEFT = currentLEFT;
        }


        //  RIGHT Button
        public void CheckRIGHT(bool RIGHT)
        {
            currentRIGHT = RIGHT;

            if (currentRIGHT == true && previousRIGHT == false)
            {
                //button just pressed, call code
                UC.Callbutton(162); // set mode to step jog

                UC.Callbutton(147); //Jog x-
            }
            if (currentRIGHT == false && previousRIGHT == true)  //additional functionality if desired
            {
                //button just released, call other code

                UC.Callbutton(229); // axis stop

                UC.Callbutton(161); // set mode to continuous jog

            }

            previousRIGHT = currentRIGHT;
        }

        # endregion buttons


        #region ShakeEvent
        public void Shake(int numShake, double timeOn)
        {

            //Timer timer = new Timer();
            //timer.Interval = Convert.ToInt32(timeOn);

            for (int i = 0; i < numShake; i++)
            {
                //timer.Start();
                controls.Vibrate(100, 100);
                Thread.Sleep(150);
                controls.Vibrate(0, 0);
                Thread.Sleep(150);

            }

        }
        
        
        
        
        #endregion  

    }
}
